sap.ui.define([
    'sap/ui/export/Spreadsheet',
    'sap/ui/export/library',
], function (Spreadsheet, exportLibrary) {
    "use strict";

    const EdmType = exportLibrary.EdmType;
    return {
        init: function (oResourceBundle) {
            this._oResourceBundle = oResourceBundle
        },

        
    };
});